//
// Started by Tom on 2/9/18.
//

#include "bigint.h"


void bigint::strip_zeros() {
	if(number.size() != 1){
		for(int j = number.size() - 1; j >0; j--){
			if(number[j] == 0) {
				number.pop_back();
			}
			else{
				break;
			}
		}
	}
}

/* Constructors
 * 
 * */

bigint::bigint() {
	
	number.clear();
	number.push_back(0);
	strip_zeros();
	
}

bigint::bigint(const std::vector<vec_bin> &that) {
	
	number.clear()
	for (vec_bin v : that) {
		number.push_back(v);
	}
	strip_zeros();
	
}

bigint::bigint(unsigned long long i) {
	
	number.clear();
	std::string istring = std::to_string(i);
	
	for(int h = 0; h < istring.length(); h++){
		number.push_back(i % 10);
		i/= 10;
	}
	strip_zeros();
}

bigint::bigint(std::string str) {
	
	std::string test =str;
	for (int i = test.length() - 1; i>=0; i--){
		number.push_back(test[i]-'0');
	}
	strip_zeros();
}


bigint::bigint(std::ifstream &infile) {
	
	number.clear();
	std::string line;
	
	if(!infile.fail()){
		while(getline(infile, line)){
		int s = stoi(line);
			for(int k = 0; k < line.length(); k++){
				number.push_back(s % 10);
				s /=10;
			}
		}
	}
	
	else{
		std::cerr << "Failure to open";
	}
	strip_zeros();
}

bigint::bigint(const bigint &that) {
	
	number.clear();
	*this = that;
	strip_zeros();
	
}


/* Number Access
 * 
 * */
const std::vector<vec_bin> &bigint::getNumber() const {
	
	return number;
	
}

vec_bin bigint::operator[](size_t index) const {
	
	return number[index];
	
}


/** Comparators
 *
 * */
bool bigint::operator==(const bigint &that) const {
	for (int i = 0; i < number.size(); i++) {
		if (number[i] != that.number[i]) {
		  return false;
		}
		return true;
	}
}

bool bigint::operator!=(const bigint &that) const {
	for (int i = 0; i < number.size(); i++) {
		if (number[i] != that.number[i]) {
			return true;
		}
		return false;
	}
}

bool bigint::operator<(const bigint &that) const {

}

bool bigint::operator<=(const bigint &that) const {

}

bool bigint::operator>(const bigint &that) const {

}

bool bigint::operator>=(const bigint &that) const {

}


/** Addition
 *
 * */

bigint bigint::add(const bigint &that) const {
	number = that;
	*this= *this + that;
	return *this;
}

bigint bigint::operator+(const bigint &that) const {
	bigint ret(that);
	ret += *this;
	return ret;	
}

bigint &bigint::operator+=(const bigint &that) {

}

bigint &bigint::operator++() {

}

bigint bigint::operator++(int) {

}


/** Subtraction
 *
 * */

bigint bigint::subtract(const bigint &that) const {
	number = that;
	*this = *this - that;
	return *this;
}

bigint bigint::operator-(const bigint &that) const {
	bigint ret(that);
	ret -= *this;
	return ret;
}

bigint &bigint::operator-=(const bigint &that) {

}

bigint &bigint::operator--() {

}

bigint bigint::operator--(int) {

}


/** Multiplication
 *
 * */

bigint bigint::multiply(const bigint &that) const {
	number = that;
	*this = *this * that;
	return *this;
}

bigint bigint::operator*(const bigint &that) const {
	bigint ret(that);
	ret *= *this;
	return ret;
}

bigint &bigint::operator*=(const bigint &that) {

}


/** Division
 *
 * */

bigint bigint::divide(const bigint &that) const {
	number = that;
	*this = *this / that;
	return *this;
}

bigint bigint::operator/(const bigint &that) const {
	bigint ret(that);
	ret /= *this;
	return ret;
}

bigint &bigint::operator/=(const bigint &that) {

}


/** Modulo
 *
 * */

bigint bigint::mod(const bigint &that) const {
	number = that;
	*this = *this / that;
	int remainder = a % b;
	return remainder;
}

bigint bigint::operator%(const bigint &that) const {
	bigint ret(that);
	ret %= *this;
	return ret;
}

bigint &bigint::operator%=(const bigint &that) {

}


/** Power
 *
 * */

bigint bigint::pow(unsigned long long n) {
	x = unsigned long long;
	y = n;
	z = pow(x,y);
	return z;
}


/** Display methods
 *
 * */

std::ostream &operator<<(std::ostream &os, const bigint &bigint1) {
	
	return os << bigint1.to_string();
	
}

std::string bigint::to_string(bool commas) const {
	std::string com;
	for (int i = number.size() - 1; i>=0; i--){
		com=com + std::to_string(number[i]);
	}
	return com;
}

std::string bigint::scientific(unsigned int decimal_points) const {
	std::string science;  // science as in scientific notation
	int fuerza = (number.size()-1); // exponent (power)
	science += char('0'+number[fuerza]);
	science += '.';
	for (int i = 0; i < (decimal_points); i++){
		if(fuerza - i - 1 < 0){
			science += '0';
		}
		else{
			science += char('0'+number[fuerza-i-1]);
		}
	}
	science += 'E';
	std::string strip = std::to_string(fuerza);
	science += strip;
	return science;
}

void bigint::to_file(std::ofstream &outfile, unsigned int wrap) {

}
