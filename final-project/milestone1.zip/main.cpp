/**
 * Started by Najib 3/21/18
 **/
#include <iterator>
#include <iostream>
#include <fstream>
#include <map>
#include <string>
#include <cctype>
#include "functions.h"
#include "bigint/bigint.h"


int main(int argc, char *argv[]) {
  std::map<std::string,int> words;
  for (int i=1; i<=argc; i++){
    std::ifstream inFile(argv[i]);


    std::string str;
    std::string empty="";
    while((str=frequencies(inFile))!=empty){
      ++words[str];
    }

    for(std::map<std::string,int>::iterator it= words.begin(); it!= words.end(); ++it){
      std::cout<<it->first<<' '<<it->second<<std::endl;
    }
}
}
