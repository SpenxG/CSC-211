/**
 * Started by Najib 3/21/18
 **/


#include <iterator>
#include <iostream>
#include <fstream>
#include <map>
#include <string>
#include <cctype>

#include "functions.h"
#include "bigint/bigint.h"


///////////////////////////////////////////////////////////////////
// FUNCTION DEFINITIONS GO HERE
///////////////////////////////////////////////////////////////////

std::string frequencies(std::istream &input){
  char x;
  std::string answer="";
  x=input.get();
  while(!std::isalpha(x) && !input.eof()){
    x=input.get();
  }
  while(std::isalpha(x)){
    answer.push_back(std::tolower(x));
    x=input.get();
  }
  return answer;
}
